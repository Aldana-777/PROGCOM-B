package Floristería;

public class FloristeriaAldana extends Casa {
    private boolean tieneFlorDecorativa;
    private boolean tieneRiachuelo;
    private boolean tieneNube;
    private boolean tieneTechoConTejas;

    /**
     * Constructor de la clase Floristería Aldana
     * @param color color de la casa
     * @param numHabitaciones número de habitaciones
     * @param numBanos número de baños
     * @param tienePatio si tiene patio
     * @param tieneParqueadero si tiene parqueadero
     * @param tieneFlorDecorativa si tiene flor decorativa en la fachada
     * @param tieneRiachuelo si tiene riachuelo en la parte trasera
     * @param tieneNube si hay nube decorativa en el cielo
     * @param tieneTechoConTejas si el techo tiene líneas de tejas
     */
    public FloristeriaAldana(String color, int numHabitaciones, int numBanos,
            boolean tienePatio, boolean tieneParqueadero,
            boolean tieneFlorDecorativa, boolean tieneRiachuelo,
            boolean tieneNube, boolean tieneTechoConTejas) {

        super(color, numHabitaciones, numBanos, tienePatio, tieneParqueadero, colorTecho, colorPuerta);
        this.tieneFlorDecorativa = tieneFlorDecorativa;
        this.tieneRiachuelo = tieneRiachuelo;
        this.tieneNube = tieneNube;
        this.tieneTechoConTejas = tieneTechoConTejas;
    }

    @Override
    public String describir() {
        String descripcion = super.describir();
        descripcion += "\nEsta es la Floristería Aldana, vista desde cinco perspectivas:";

        descripcion += "\n\n🔸 Vista Frontal:\n- Fachada verde lima con techo negro triangular." +
                "\n- Puerta azul celeste en el centro.";
        if (tieneFlorDecorativa) {
            descripcion += "\n- Flor decorativa con pétalos amarillos sobre fondo negro.";
        }

        descripcion += "\n\n🔸 Vista Trasera:\n- Triángulo dorado decorativo bajo el techo." +
                "\n- Ventana blanca rectangular con divisiones negras.";
        if (tieneRiachuelo) {
            descripcion += "\n- Riachuelo azul claro serpenteando desde la base.";
        }
        if (tieneNube) {
            descripcion += "\n- Nube gris compuesta por varios círculos flotando en el cielo.";
        }

        descripcion += "\n\n🔸 Vista Lateral Izquierda:\n- Muro estrecho con tres postes grises decorativos.";

        descripcion += "\n\n🔸 Vista Lateral Derecha:\n- Muro similar al izquierdo, sin postes decorativos.";

        descripcion += "\n\n🔸 Vista Superior:\n- Techo negro rectangular.";
        if (tieneTechoConTejas) {
            descripcion += "\n- Líneas grises verticales que simulan tejas.";
        }

        return descripcion;
    }
}
