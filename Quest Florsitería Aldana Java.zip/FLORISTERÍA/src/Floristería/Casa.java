package Floristería;

public class Casa {
	//Atributos de clase
	private String color;
	private int numHabitaciones;
	private int numBanos;
	private boolean tienePatio;
	private boolean tieneParqueadero;
	private String colorTecho;
	private String colorPuerta;
	
	/**
	 * Constructor de la clase casa
	 * @param color color de la casa
	 * @param numHabitaciones número de habitaciones de la casa
	 * @param numBanos número de baños de la casa
	 * @param tienePatio coloque true o false dependiendo si hay o no patio
	 * @param tieneParqueadero coloque true o false si tiene parqueadero o no
	 */
	
	public Casa(String color, int numHabitaciones, int numBanos, boolean tienePatio, boolean tieneParqueadero, String colorTecho, String colorPuerta) {
		this.color=color;
		this.numHabitaciones=numHabitaciones;
		this.numBanos=numBanos;
		this.tienePatio=tienePatio;
		this.tieneParqueadero=tieneParqueadero;
		this.colorTecho=colorTecho;
		this.colorPuerta=colorPuerta;
		
	}
	
	public String describir() {
		String descripcion=" La casa es de color " + this.color +
				". Tiene " + this.numHabitaciones + " habitación(es) y " +
				this.numBanos + " baño(s)." + ". Tiene techo color " + this.colorTecho + ". Tiene puerta color " + this.colorPuerta ;
			if (tienePatio) {descripcion+="\nTiene Patio.";}
			if (tieneParqueadero) {descripcion+="\nTiene Parqueadero.";}
			return descripcion;
	}
	
	public void pintar(String nuevoColor) {
		this.color=nuevoColor;
		System.out.println("La casa a sido pintada de color" + this.color);

	}
	
}
