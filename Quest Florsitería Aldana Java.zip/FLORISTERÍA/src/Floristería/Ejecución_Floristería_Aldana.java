package Floristería;

public class Ejecución_Floristería_Aldana {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Casa aldanaCasa= new Casa("Verde con negro", 5 , 2 ,true,true,"negro","celeste");
		System.out.println(aldanaCasa.describir());
		aldanaCasa.pintar("Le agrego el A1");
		System.out.println(aldanaCasa.describir());
	}
}

